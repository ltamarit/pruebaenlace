# camp20
repositorio para guardar el dockerfile de la imagen camp20
